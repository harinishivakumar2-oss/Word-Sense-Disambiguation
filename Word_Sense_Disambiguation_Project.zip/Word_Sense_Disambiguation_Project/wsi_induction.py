"""
Simple Word Sense Induction (WSI) using WordNet lexical relations.
Run: python wsi_induction.py
Groups a word's WordNet senses by shared lexical relations for inspection.
"""
from nltk.corpus import wordnet as wn
import nltk

for package, path in [("wordnet", "corpora/wordnet"), ("omw-1.4", "corpora/omw-1.4")]:
    try:
        nltk.data.find(path)
    except LookupError:
        nltk.download(package, quiet=True)

def sense_signature(synset):
    words = set(synset.definition().lower().replace(",", " ").replace(".", " ").split())
    words.update(lemma.name().replace("_", " ").lower() for lemma in synset.lemmas())
    for related in synset.hypernyms() + synset.hyponyms():
        words.update(lemma.name().replace("_", " ").lower() for lemma in related.lemmas())
    return words

def induce_groups(word):
    senses = wn.synsets(word)
    if not senses:
        print(f"No WordNet senses found for: {word}")
        return
    groups = []
    for syn in senses:
        sig = sense_signature(syn)
        best_idx, best_overlap = None, 0
        for idx, group in enumerate(groups):
            overlap = len(sig & group["signature"])
            if overlap > best_overlap:
                best_idx, best_overlap = idx, overlap
        if best_idx is None or best_overlap == 0:
            groups.append({"signature": set(sig), "senses": [syn]})
        else:
            groups[best_idx]["signature"].update(sig)
            groups[best_idx]["senses"].append(syn)
    print(f"\nWord Sense Induction for '{word}'")
    for i, group in enumerate(groups, 1):
        print(f"\nInduced group {i}:")
        for syn in group["senses"]:
            print(f"  - {syn.name()}: {syn.definition()}")
        print("  Shared terms:", ", ".join(sorted(group["signature"])[:12]))

if __name__ == "__main__":
    induce_groups("bank")
    induce_groups("plant")
