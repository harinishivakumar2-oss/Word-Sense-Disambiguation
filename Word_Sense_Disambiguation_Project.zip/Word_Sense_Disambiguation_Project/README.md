# Word Sense Disambiguation using WordNet

## Aim
Develop a Word Sense Disambiguation (WSD) system using WordNet synsets and lexical relations.

## Features
- Enter an ambiguous word and its context sentence.
- Retrieves possible meanings (WordNet synsets).
- Uses a simplified Lesk-style context/gloss word-overlap score to rank senses.
- Displays sense definitions, examples, and lexical relations such as synonyms, antonyms, hypernyms, and hyponyms.
- Includes a separate basic Word Sense Induction (WSI) script for grouping senses by lexical overlap.
- Includes sample sentences for bank, plant, and bat.

## Run in VS Code (Windows)
1. Extract the ZIP and open the `Word_Sense_Disambiguation_Project` folder in VS Code.
2. Open Terminal > New Terminal.
3. Create a virtual environment (optional):
   ```powershell
   python -m venv .venv
   ```
4. Install dependencies:
   ```powershell
   python -m pip install -r requirements.txt
   ```
5. Start the app:
   ```powershell
   python -m streamlit run app.py
   ```
6. The first run may download WordNet and NLTK tokenizer/tagger resources. Keep the internet connection on.
7. Enter `bank` and use either sentence:
   - She deposited money at the bank before going home.
   - The fisherman sat on the bank of the river.
   Click **Disambiguate word**.
8. To demonstrate the induction-based script in the terminal:
   ```powershell
   python wsi_induction.py
   ```

## Method
- WordNet stores word meanings as synsets (sets of synonyms with a shared meaning).
- The simplified Lesk method ranks a sense by overlap between the sentence context and the sense definition/examples.
- Lexical relations are displayed from WordNet, including hypernyms (more general concepts), hyponyms (more specific concepts), antonyms, meronyms (parts/members/substances), and holonyms (whole/member/substance relations).
- `wsi_induction.py` demonstrates a basic grouping heuristic based on overlapping definitions and related words; it is illustrative, not a research-grade WSI model.

## Important limitation
The overlap score is a simple heuristic and is not a calibrated probability. Short sentences or missing context words can lead to incorrect rankings.
