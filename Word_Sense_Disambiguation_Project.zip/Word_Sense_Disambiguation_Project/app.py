import streamlit as st
import pandas as pd
import nltk
from nltk.corpus import wordnet as wn
from nltk.tokenize import word_tokenize
from nltk import pos_tag

st.set_page_config(page_title="Word Sense Disambiguation", page_icon="📚", layout="wide")
st.title("Word Sense Disambiguation using WordNet")
st.write("Identify the likely meaning of an ambiguous word from its context using WordNet synsets, definitions, examples, and lexical relations.")

@st.cache_resource
def setup_wordnet():
    resources = [
        ("corpora/wordnet", "wordnet"),
        ("corpora/omw-1.4", "omw-1.4"),
        ("tokenizers/punkt", "punkt"),
        ("taggers/averaged_perceptron_tagger_eng", "averaged_perceptron_tagger_eng"),
        ("taggers/averaged_perceptron_tagger", "averaged_perceptron_tagger"),
    ]
    for path, package in resources:
        try:
            nltk.data.find(path)
        except LookupError:
            try:
                nltk.download(package, quiet=True)
            except Exception:
                pass
    try:
        nltk.download("punkt_tab", quiet=True)
    except Exception:
        pass
    return True

setup_wordnet()

def get_pos(word):
    try:
        tag = pos_tag([word])[0][1]
        if tag.startswith("N"): return wn.NOUN
        if tag.startswith("V"): return wn.VERB
        if tag.startswith("J"): return wn.ADJ
        if tag.startswith("R"): return wn.ADV
    except Exception:
        pass
    return None

def overlap_score(context_words, synset):
    # Simplified Lesk-style score: overlap between context words and sense gloss/examples.
    gloss = (synset.definition() + " " + " ".join(synset.examples())).lower()
    gloss_words = set(word_tokenize(gloss)) if gloss else set()
    return len(context_words & gloss_words)

def related_terms(synset):
    terms = set()
    for lemma in synset.lemmas():
        terms.add(lemma.name().replace("_", " "))
        for antonym in lemma.antonyms():
            terms.add("antonym: " + antonym.name().replace("_", " "))
    for hyper in synset.hypernyms():
        terms.add("hypernym: " + hyper.name().split(".")[0].replace("_", " "))
    for hypo in synset.hyponyms()[:8]:
        terms.add("hyponym: " + hypo.name().split(".")[0].replace("_", " "))
    for mer in synset.member_holonyms() + synset.part_holonyms() + synset.substance_holonyms():
        terms.add("holonym: " + mer.name().split(".")[0].replace("_", " "))
    for mer in synset.member_meronyms() + synset.part_meronyms() + synset.substance_meronyms():
        terms.add("meronym: " + mer.name().split(".")[0].replace("_", " "))
    return sorted(terms)

def disambiguate(sentence, target):
    tokens = word_tokenize(sentence)
    context = {t.lower() for t in tokens if t.isalpha() and t.lower() != target.lower()}
    candidates = wn.synsets(target)
    if not candidates:
        return [], "WordNet has no senses for this word."
    pos = get_pos(target)
    if pos:
        filtered = [s for s in candidates if s.pos() == pos]
        if filtered:
            candidates = filtered
    scored = []
    for syn in candidates:
        score = overlap_score(context, syn)
        scored.append((score, syn))
    scored.sort(key=lambda x: (x[0], x[1].name()), reverse=True)
    return scored, None

with st.sidebar:
    st.header("Input")
    target = st.text_input("Ambiguous word", value="bank").strip()
    sentence = st.text_area("Sentence / context", value="She deposited money at the bank before going home.", height=130)
    st.caption("Try: 'The fisherman sat on the bank of the river.'")
    run = st.button("Disambiguate word", type="primary")

st.subheader("How it works")
st.write("1. Find WordNet senses (synsets) for the target word. 2. Compare context words with each sense's definition and example sentences using a simplified Lesk overlap score. 3. Rank senses and show lexical relations such as synonyms, antonyms, hypernyms, and hyponyms.")

if run:
    if not target or not sentence.strip():
        st.error("Enter both an ambiguous word and a context sentence.")
        st.stop()
    scored, error = disambiguate(sentence, target)
    if error:
        st.error(error)
        st.stop()
    st.subheader("Ranked word senses")
    rows = []
    for rank, (score, syn) in enumerate(scored, 1):
        rows.append({
            "Rank": rank,
            "WordNet synset": syn.name(),
            "Part of speech": syn.pos(),
            "Overlap score": score,
            "Definition": syn.definition(),
            "Example": "; ".join(syn.examples()) or "No example supplied"
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    best_score, best = scored[0]
    st.subheader("Most likely sense")
    st.markdown(f"**{best.name()}** — {best.definition()}")
    st.write(f"Context-gloss overlap score: **{best_score}**. This is a simple ranking score, not a calibrated probability.")
    st.subheader("Lexical relations for the selected sense")
    terms = related_terms(best)
    if terms:
        st.write(", ".join(terms[:35]))
    else:
        st.write("No listed relations were found for this synset.")
    st.info("Interpretation: compare the selected definition with the sentence context. If two senses have the same overlap score, the ranking may be uncertain.")
